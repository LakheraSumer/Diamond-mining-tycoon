using DiamondMine.Simulation;
using UnityEngine;

namespace DiamondMine.Runtime
{
    /// <summary>
    /// Existing yard blockout. Plot 0 uses imported Blender assets; the remaining
    /// plots and production stations keep their current temporary presentation.
    /// </summary>
    public static class YardArt
    {
        public struct Crew
        {
            public Transform Root;
            public Transform Arm;
            public Transform ToolSocket;
            public Transform Helmet;
            public Transform Head;
            public Transform Cloth;
        }

        public static TextMesh[] BunkerLabels;

        public static TimberBunkerArea BuildSite(Transform parent)
        {
            Terrain(parent);
            TimberBunkerArea hero = TimberBunkerArea.Create(parent);
            for (int i = 0; i < 8; i++)
            {
                float x = -9f + i * 2.4f;
                Tree(parent, new Vector3(x, 0f, -3.4f), 0.7f + (i % 3) * 0.15f);
                Tree(parent, new Vector3(-8.5f + i * 2.2f, 0f, 11.5f), 0.9f);
            }
            BunkerLabels = new TextMesh[WorldGenerator.VisibleYardPlots];
            for (int plot = 0; plot < WorldGenerator.VisibleYardPlots; plot++)
            {
                // Plot 0 is the authored Blender slice. Never overwrite it with a primitive bunker/cart.
                if (plot == 0) continue;
                YardPoint door = YardLayout.Entrance(plot);
                var at = new Vector3((float)door.X, 0f, (float)door.Z);
                Color ore = plot == 2 ? new Color(0.45f, 0.82f, 0.95f) : plot == 4 ? new Color(0.92f, 0.78f, 0.28f) : new Color(0.62f, 0.58f, 0.54f);
                BunkerLabels[plot] = Bunker(parent, at, plot + 1, ore, plot >= WorldGenerator.StarterCount);
                if (plot < 6)
                    Cart(parent, at + new Vector3(0f, 0f, -1.15f), ore);
            }
            // Authored curved track joins this existing main line beyond the reviewed patch.
            Rails(parent, new Vector3(-6.1f, 0.02f, 4.86f), new Vector3(6.5f, 0.02f, 4.86f));
            Crusher(parent, new Vector3(-1.6f, 0f, 2.6f));
            WashTank(parent, new Vector3(0.6f, 0f, 2.6f));
            SortTable(parent, new Vector3(2.6f, 0f, 2.6f));
            CutBooth(parent, new Vector3(4.4f, 0f, 2.6f));
            PolishBench(parent, new Vector3(6.1f, 0f, 2.6f));
            Refinery(parent, new Vector3(8f, 0f, 2.4f));
            Workshop(parent, new Vector3(6.4f, 0f, 0.2f));
            Boutique(parent, new Vector3(4.2f, 0f, -1.2f));
            string[] bins = { "Stone", "Iron", "Copper", "Silver", "Gold" };
            Color[] binColors =
            {
                new Color(0.62f, 0.58f, 0.52f),
                new Color(0.55f, 0.32f, 0.26f),
                new Color(0.78f, 0.46f, 0.24f),
                new Color(0.78f, 0.8f, 0.82f),
                new Color(0.9f, 0.72f, 0.22f)
            };
            for (int i = 0; i < bins.Length; i++)
                Bin(parent, new Vector3(-7.2f + i * 1.45f, 0f, -2.5f), bins[i], binColors[i]);
            PlaceCrew(parent, "pavi", new Vector3(0.9f, 0f, 1.5f), 20f);
            PlaceCrew(parent, "sola", new Vector3(5.5f, 0f, -1.6f), -30f);
            return hero;
        }

        public static Crew BuildCrew(CharacterDef person, Transform parent)
        {
            if (person == null)
                person = JourneyCatalog.AllCharacters[0];
            var rootObject = new GameObject(person.Id);
            rootObject.transform.SetParent(parent, false);
            Transform root = rootObject.transform;
            float tall = Tall(person.Id);
            float wide = Wide(person.Id);
            Color skin = Hex(person.Skin);
            Color cloth = Hex(person.Cloth);
            Color helmet = Hex(person.Helmet);
            Color accent = Hex(person.Accent);
            Color hair = Hex(person.Hair);
            Transform hips = Joint(root, "Hips", PrimitiveType.Capsule, new Vector3(0f, 0.92f * tall, 0f), new Vector3(0.34f * wide, 0.16f * tall, 0.24f), Vector3.zero, cloth, 0.15f, 0f);
            Transform clothBody = Joint(hips, "Cloth", PrimitiveType.Capsule, new Vector3(0f, 0.28f * tall, 0f), new Vector3(0.42f * wide, 0.28f * tall, 0.28f), Vector3.zero, cloth, 0.2f, 0f);
            Part(clothBody, "Chest", PrimitiveType.Cube, new Vector3(0f, 0.12f, 0.04f), new Vector3(0.46f * wide, 0.28f * tall, 0.22f), Vector3.zero, cloth, 0.18f, 0f);
            Transform head = Joint(clothBody, "Head", PrimitiveType.Sphere, new Vector3(0f, 0.42f * tall, 0f), new Vector3(0.34f, 0.36f, 0.32f), Vector3.zero, skin, 0.25f, 0f);
            Part(head, "Hair", PrimitiveType.Sphere, new Vector3(0f, 0.08f, -0.02f), new Vector3(0.38f, 0.22f, 0.34f), Vector3.zero, hair, 0.3f, 0f);
            Part(head, "EyeL", PrimitiveType.Sphere, new Vector3(-0.07f, 0.02f, 0.14f), new Vector3(0.06f, 0.06f, 0.04f), Vector3.zero, new Color(0.15f, 0.12f, 0.1f), 0.4f, 0f);
            Part(head, "EyeR", PrimitiveType.Sphere, new Vector3(0.07f, 0.02f, 0.14f), new Vector3(0.06f, 0.06f, 0.04f), Vector3.zero, new Color(0.15f, 0.12f, 0.1f), 0.4f, 0f);
            Transform helmetTransform = Joint(head, "Helmet", PrimitiveType.Sphere, new Vector3(0f, 0.1f, 0f), new Vector3(0.42f, 0.28f, 0.42f), Vector3.zero, helmet, 0.45f, 0.15f);
            Part(helmetTransform, "Lamp", PrimitiveType.Sphere, new Vector3(0f, 0.02f, 0.18f), new Vector3(0.1f, 0.08f, 0.06f), Vector3.zero, new Color(1f, 0.95f, 0.7f), 0.7f, 0f);
            Transform arm = Joint(clothBody, "Arm", PrimitiveType.Capsule, new Vector3(0.28f * wide, 0.02f, 0.04f), new Vector3(0.12f, 0.22f * tall, 0.12f), new Vector3(0f, 0f, 70f), skin, 0.2f, 0f);
            Part(clothBody, "ArmL", PrimitiveType.Capsule, new Vector3(-0.28f * wide, 0.02f, 0.04f), new Vector3(0.12f, 0.22f * tall, 0.12f), new Vector3(0f, 0f, -70f), skin, 0.2f, 0f);
            var socketObject = new GameObject("ToolSocket");
            socketObject.transform.SetParent(arm, false);
            socketObject.transform.localPosition = new Vector3(0f, -0.55f, 0.1f);
            Part(hips, "LegR", PrimitiveType.Capsule, new Vector3(0.1f * wide, -0.42f * tall, 0f), new Vector3(0.14f, 0.24f * tall, 0.14f), Vector3.zero, cloth, 0.15f, 0f);
            Part(hips, "LegL", PrimitiveType.Capsule, new Vector3(-0.1f * wide, -0.42f * tall, 0f), new Vector3(0.14f, 0.24f * tall, 0.14f), Vector3.zero, cloth, 0.15f, 0f);
            Part(hips, "BootR", PrimitiveType.Cube, new Vector3(0.1f * wide, -0.78f * tall, 0.06f), new Vector3(0.16f, 0.12f, 0.26f), Vector3.zero, accent, 0.3f, 0f);
            Part(hips, "BootL", PrimitiveType.Cube, new Vector3(-0.1f * wide, -0.78f * tall, 0.06f), new Vector3(0.16f, 0.12f, 0.26f), Vector3.zero, accent, 0.3f, 0f);
            Accessory(person, clothBody, hips, head, accent, helmet);
            return new Crew
            {
                Root = root,
                Arm = arm,
                ToolSocket = socketObject.transform,
                Helmet = helmetTransform,
                Head = head,
                Cloth = clothBody
            };
        }

        static void Accessory(CharacterDef person, Transform chest, Transform hips, Transform head, Color accent, Color helmet)
        {
            string key = person.Accessory ?? "";
            if (key == "scarf")
            {
                Part(chest, "Scarf", PrimitiveType.Cube, new Vector3(0.05f, 0.18f, 0.16f), new Vector3(0.28f, 0.08f, 0.08f), new Vector3(0f, 20f, 12f), new Color(0.96f, 0.93f, 0.84f), 0.1f, 0f);
                Part(hips, "Pouch", PrimitiveType.Cube, new Vector3(0.22f, 0.05f, 0.12f), new Vector3(0.16f, 0.14f, 0.08f), new Vector3(0f, 0f, 8f), new Color(0.62f, 0.42f, 0.22f), 0.15f, 0f);
                Pick(chest, new Color(0.35f, 0.35f, 0.38f));
            }
            else if (key == "pouch")
            {
                Part(hips, "Belt", PrimitiveType.Cube, new Vector3(0f, 0.05f, 0.12f), new Vector3(0.4f, 0.08f, 0.08f), Vector3.zero, accent, 0.2f, 0.1f);
                Part(hips, "KneeR", PrimitiveType.Sphere, new Vector3(0.12f, -0.35f, 0.08f), new Vector3(0.12f, 0.1f, 0.1f), Vector3.zero, new Color(0.25f, 0.25f, 0.28f), 0.3f, 0.2f);
                Part(hips, "KneeL", PrimitiveType.Sphere, new Vector3(-0.12f, -0.35f, 0.08f), new Vector3(0.12f, 0.1f, 0.1f), Vector3.zero, new Color(0.25f, 0.25f, 0.28f), 0.3f, 0.2f);
            }
            else if (key == "tubes")
            {
                Part(chest, "Tubes", PrimitiveType.Cylinder, new Vector3(0.16f, 0.05f, 0.16f), new Vector3(0.05f, 0.12f, 0.05f), new Vector3(20f, 0f, 0f), new Color(0.7f, 0.85f, 0.9f), 0.6f, 0.1f);
                Part(head, "Glass", PrimitiveType.Cylinder, new Vector3(0.16f, -0.02f, 0.16f), new Vector3(0.08f, 0.02f, 0.08f), new Vector3(80f, 0f, 0f), new Color(0.8f, 0.9f, 0.95f), 0.7f, 0.1f);
            }
            else if (key == "gloves")
            {
                Part(chest, "Drill", PrimitiveType.Cylinder, new Vector3(0f, 0.15f, -0.18f), new Vector3(0.12f, 0.2f, 0.12f), new Vector3(70f, 0f, 0f), accent, 0.45f, 0.4f);
                Part(chest, "Glove", PrimitiveType.Sphere, new Vector3(0.32f, -0.05f, 0.08f), new Vector3(0.12f, 0.1f, 0.1f), Vector3.zero, accent, 0.3f, 0.2f);
            }
            else if (key == "goggles")
            {
                Part(head, "Goggles", PrimitiveType.Cylinder, new Vector3(0f, 0f, 0.16f), new Vector3(0.22f, 0.03f, 0.12f), new Vector3(90f, 0f, 0f), new Color(0.85f, 0.95f, 1f), 0.7f, 0.1f);
                Part(chest, "Apron", PrimitiveType.Cube, new Vector3(0f, -0.05f, 0.12f), new Vector3(0.36f, 0.42f, 0.06f), Vector3.zero, helmet, 0.1f, 0f);
                Part(chest, "Pan", PrimitiveType.Cylinder, new Vector3(0.28f, -0.05f, 0.16f), new Vector3(0.16f, 0.03f, 0.16f), Vector3.zero, new Color(0.55f, 0.58f, 0.62f), 0.5f, 0.4f);
            }
            else if (key == "tray")
            {
                Part(chest, "Tray", PrimitiveType.Cube, new Vector3(0.22f, 0f, 0.2f), new Vector3(0.22f, 0.04f, 0.16f), Vector3.zero, new Color(0.75f, 0.78f, 0.8f), 0.4f, 0.3f);
                Part(chest, "Patch", PrimitiveType.Cube, new Vector3(-0.16f, 0.05f, 0.12f), new Vector3(0.1f, 0.1f, 0.04f), Vector3.zero, accent, 0.1f, 0f);
            }
            else if (key == "glasses")
            {
                Part(head, "Glasses", PrimitiveType.Cube, new Vector3(0f, 0.02f, 0.16f), new Vector3(0.24f, 0.06f, 0.04f), Vector3.zero, new Color(0.45f, 0.3f, 0.7f), 0.6f, 0.1f);
                Part(hips, "Case", PrimitiveType.Cube, new Vector3(-0.22f, 0.02f, 0.1f), new Vector3(0.12f, 0.1f, 0.08f), Vector3.zero, accent, 0.2f, 0f);
            }
            else if (key == "cloth")
            {
                Part(hips, "PolishCloth", PrimitiveType.Cube, new Vector3(0.2f, 0.08f, 0.12f), new Vector3(0.14f, 0.1f, 0.06f), new Vector3(0f, 15f, 0f), new Color(0.95f, 0.94f, 0.9f), 0.05f, 0f);
            }
            else if (key == "loop")
            {
                Part(chest, "Apron", PrimitiveType.Cube, new Vector3(0f, -0.08f, 0.12f), new Vector3(0.38f, 0.46f, 0.05f), Vector3.zero, helmet, 0.1f, 0f);
                Part(chest, "Loop", PrimitiveType.Cylinder, new Vector3(0.24f, 0.05f, 0.14f), new Vector3(0.08f, 0.02f, 0.08f), new Vector3(90f, 0f, 0f), accent, 0.5f, 0.5f);
            }
            else if (key == "badge")
            {
                Part(chest, "Waistcoat", PrimitiveType.Cube, new Vector3(0f, 0.02f, 0.12f), new Vector3(0.34f, 0.36f, 0.06f), Vector3.zero, helmet, 0.15f, 0f);
                Part(chest, "Badge", PrimitiveType.Sphere, new Vector3(0.1f, 0.12f, 0.16f), new Vector3(0.08f, 0.08f, 0.04f), Vector3.zero, accent, 0.6f, 0.3f);
            }
            else if (key == "cart")
            {
                Part(hips, "Handcart", PrimitiveType.Cube, new Vector3(0.34f, -0.15f, 0.1f), new Vector3(0.18f, 0.16f, 0.22f), Vector3.zero, new Color(0.7f, 0.72f, 0.75f), 0.4f, 0.3f);
                Part(hips, "Wheel", PrimitiveType.Cylinder, new Vector3(0.34f, -0.32f, 0.18f), new Vector3(0.08f, 0.03f, 0.08f), new Vector3(0f, 0f, 90f), new Color(0.15f, 0.15f, 0.16f), 0.2f, 0.1f);
            }
            else if (key == "blueprint")
            {
                Part(chest, "Tube", PrimitiveType.Cylinder, new Vector3(-0.22f, 0.12f, 0.08f), new Vector3(0.06f, 0.18f, 0.06f), new Vector3(0f, 0f, 40f), accent, 0.4f, 0.2f);
                Part(hips, "Belt", PrimitiveType.Cube, new Vector3(0f, 0.02f, 0.14f), new Vector3(0.42f, 0.08f, 0.06f), Vector3.zero, new Color(0.35f, 0.28f, 0.18f), 0.15f, 0f);
            }
            else
            {
                Pick(chest, accent);
            }
        }

        static void Pick(Transform chest, Color metal)
        {
            Part(chest, "Pick", PrimitiveType.Cube, new Vector3(0.34f, -0.15f, 0.12f), new Vector3(0.06f, 0.28f, 0.06f), new Vector3(0f, 0f, 20f), new Color(0.42f, 0.28f, 0.16f), 0.15f, 0f);
            Part(chest, "Head", PrimitiveType.Cube, new Vector3(0.42f, -0.32f, 0.12f), new Vector3(0.18f, 0.06f, 0.06f), Vector3.zero, metal, 0.5f, 0.6f);
        }

        static TextMesh Bunker(Transform parent, Vector3 at, int number, Color ore, bool locked)
        {
            var root = new GameObject("Bunker" + number);
            root.transform.SetParent(parent, false);
            root.transform.position = at;
            Color rock = new Color(0.48f, 0.46f, 0.43f);
            Color timber = new Color(0.5f, 0.3f, 0.16f);
            Color timberDark = new Color(0.32f, 0.18f, 0.09f);
            Part(root.transform, "RockL", PrimitiveType.Cube, new Vector3(-0.85f, 0.9f, 0.3f), new Vector3(0.7f, 1.8f, 1.1f), new Vector3(0f, 8f, 0f), rock, 0.08f, 0f);
            Part(root.transform, "RockR", PrimitiveType.Cube, new Vector3(0.85f, 0.9f, 0.3f), new Vector3(0.7f, 1.8f, 1.1f), new Vector3(0f, -8f, 0f), rock, 0.08f, 0f);
            Part(root.transform, "RockTop", PrimitiveType.Cube, new Vector3(0f, 1.85f, 0.25f), new Vector3(1.8f, 0.55f, 1.2f), Vector3.zero, rock, 0.08f, 0f);
            Part(root.transform, "Mouth", PrimitiveType.Cube, new Vector3(0f, 0.85f, 0.15f), new Vector3(0.9f, 1.15f, 0.35f), Vector3.zero, new Color(0.08f, 0.07f, 0.06f), 0.05f, 0f);
            Part(root.transform, "PostL", PrimitiveType.Cube, new Vector3(-0.48f, 0.9f, -0.05f), new Vector3(0.12f, 1.7f, 0.12f), Vector3.zero, timber, 0.2f, 0f);
            Part(root.transform, "PostR", PrimitiveType.Cube, new Vector3(0.48f, 0.9f, -0.05f), new Vector3(0.12f, 1.7f, 0.12f), Vector3.zero, timber, 0.2f, 0f);
            Part(root.transform, "Lintel", PrimitiveType.Cube, new Vector3(0f, 1.7f, -0.05f), new Vector3(1.15f, 0.14f, 0.16f), Vector3.zero, timberDark, 0.2f, 0f);
            Part(root.transform, "BraceL", PrimitiveType.Cube, new Vector3(-0.28f, 1.45f, -0.05f), new Vector3(0.5f, 0.08f, 0.1f), new Vector3(0f, 0f, 28f), timber, 0.2f, 0f);
            Part(root.transform, "BraceR", PrimitiveType.Cube, new Vector3(0.28f, 1.45f, -0.05f), new Vector3(0.5f, 0.08f, 0.1f), new Vector3(0f, 0f, -28f), timber, 0.2f, 0f);
            Part(root.transform, "Tie1", PrimitiveType.Cube, new Vector3(0f, 0.06f, -0.55f), new Vector3(0.7f, 0.06f, 0.12f), Vector3.zero, timberDark, 0.15f, 0f);
            Part(root.transform, "Tie2", PrimitiveType.Cube, new Vector3(0f, 0.06f, -1.05f), new Vector3(0.7f, 0.06f, 0.12f), Vector3.zero, timberDark, 0.15f, 0f);
            Part(root.transform, "RailL", PrimitiveType.Cube, new Vector3(-0.16f, 0.1f, -0.8f), new Vector3(0.05f, 0.04f, 1.3f), Vector3.zero, new Color(0.25f, 0.27f, 0.3f), 0.55f, 0.7f);
            Part(root.transform, "RailR", PrimitiveType.Cube, new Vector3(0.16f, 0.1f, -0.8f), new Vector3(0.05f, 0.04f, 1.3f), Vector3.zero, new Color(0.25f, 0.27f, 0.3f), 0.55f, 0.7f);
            Part(root.transform, "Ore", PrimitiveType.Cube, new Vector3(-0.7f, 0.28f, -0.35f), new Vector3(0.28f, 0.22f, 0.22f), new Vector3(0f, 18f, 8f), ore, 0.35f, 0.05f);
            Part(root.transform, "Lantern", PrimitiveType.Sphere, new Vector3(0.62f, 1.35f, -0.1f), new Vector3(0.12f, 0.12f, 0.12f), Vector3.zero, locked ? new Color(0.4f, 0.4f, 0.42f) : new Color(1f, 0.85f, 0.4f), 0.6f, 0f);
            return Plate(root.transform, number.ToString(), new Vector3(0f, 2.15f, -0.15f));
        }

        public static Transform Cart(Transform parent, Vector3 at, Color ore)
        {
            var root = new GameObject("Cart");
            root.transform.SetParent(parent, false);
            root.transform.position = at;
            Color wood = new Color(0.45f, 0.26f, 0.12f);
            Part(root.transform, "Bed", PrimitiveType.Cube, new Vector3(0f, 0.28f, 0f), new Vector3(0.55f, 0.22f, 0.38f), Vector3.zero, wood, 0.2f, 0f);
            Part(root.transform, "Lip", PrimitiveType.Cube, new Vector3(0f, 0.42f, 0.16f), new Vector3(0.58f, 0.08f, 0.06f), Vector3.zero, wood, 0.2f, 0f);
            Part(root.transform, "Load", PrimitiveType.Cube, new Vector3(0f, 0.46f, -0.02f), new Vector3(0.36f, 0.16f, 0.24f), new Vector3(8f, 12f, 0f), ore, 0.3f, 0.05f);
            Wheel(root.transform, new Vector3(-0.22f, 0.12f, 0.14f));
            Wheel(root.transform, new Vector3(0.22f, 0.12f, 0.14f));
            Wheel(root.transform, new Vector3(-0.22f, 0.12f, -0.14f));
            Wheel(root.transform, new Vector3(0.22f, 0.12f, -0.14f));
            return root.transform;
        }

        static void Wheel(Transform parent, Vector3 at)
        {
            Part(parent, "Wheel", PrimitiveType.Cylinder, at, new Vector3(0.12f, 0.04f, 0.12f), new Vector3(0f, 0f, 90f), new Color(0.12f, 0.12f, 0.13f), 0.25f, 0.2f);
        }

        static void Crusher(Transform parent, Vector3 at)
        {
            var root = new GameObject("Crusher");
            root.transform.SetParent(parent, false);
            root.transform.position = at;
            Color teal = new Color(0.16f, 0.55f, 0.62f);
            Color tealDark = new Color(0.1f, 0.38f, 0.46f);
            Part(root.transform, "Base", PrimitiveType.Cube, new Vector3(0f, 0.35f, 0f), new Vector3(1.4f, 0.7f, 0.9f), Vector3.zero, teal, 0.4f, 0.25f);
            Part(root.transform, "Housing", PrimitiveType.Cube, new Vector3(0f, 0.85f, 0f), new Vector3(1f, 0.55f, 0.7f), Vector3.zero, tealDark, 0.45f, 0.3f);
            Part(root.transform, "Drum", PrimitiveType.Cylinder, new Vector3(0.15f, 0.85f, 0f), new Vector3(0.42f, 0.38f, 0.42f), new Vector3(0f, 0f, 90f), new Color(0.55f, 0.58f, 0.62f), 0.6f, 0.7f);
            Part(root.transform, "Hopper", PrimitiveType.Cube, new Vector3(-0.45f, 1.15f, 0f), new Vector3(0.4f, 0.35f, 0.4f), new Vector3(0f, 0f, 18f), teal, 0.35f, 0.2f);
            Conveyor(root.transform, new Vector3(0.95f, 0.42f, 0f));
            Plate(root.transform, "Crush", new Vector3(0f, 1.35f, -0.2f));
        }

        static void WashTank(Transform parent, Vector3 at)
        {
            var root = new GameObject("Wash");
            root.transform.SetParent(parent, false);
            root.transform.position = at;
            Color teal = new Color(0.2f, 0.62f, 0.7f);
            Part(root.transform, "Tank", PrimitiveType.Cylinder, new Vector3(0f, 0.55f, 0f), new Vector3(0.7f, 0.35f, 0.7f), Vector3.zero, teal, 0.5f, 0.2f);
            Part(root.transform, "Water", PrimitiveType.Cylinder, new Vector3(0f, 0.92f, 0f), new Vector3(0.55f, 0.04f, 0.55f), Vector3.zero, new Color(0.45f, 0.75f, 0.9f), 0.7f, 0.05f);
            Part(root.transform, "Pipe", PrimitiveType.Cylinder, new Vector3(0.45f, 0.7f, 0f), new Vector3(0.08f, 0.28f, 0.08f), new Vector3(0f, 0f, 70f), new Color(0.7f, 0.74f, 0.78f), 0.55f, 0.6f);
            Plate(root.transform, "Wash", new Vector3(0f, 1.25f, 0f));
        }

        static void SortTable(Transform parent, Vector3 at)
        {
            var root = new GameObject("Sort");
            root.transform.SetParent(parent, false);
            root.transform.position = at;
            Part(root.transform, "Table", PrimitiveType.Cube, new Vector3(0f, 0.55f, 0f), new Vector3(1.1f, 0.12f, 0.7f), Vector3.zero, new Color(0.55f, 0.58f, 0.6f), 0.35f, 0.3f);
            Part(root.transform, "Leg", PrimitiveType.Cube, new Vector3(0f, 0.25f, 0f), new Vector3(0.9f, 0.4f, 0.5f), Vector3.zero, new Color(0.16f, 0.48f, 0.55f), 0.3f, 0.15f);
            Part(root.transform, "Tray", PrimitiveType.Cube, new Vector3(0.15f, 0.66f, 0f), new Vector3(0.35f, 0.06f, 0.28f), Vector3.zero, new Color(0.75f, 0.78f, 0.82f), 0.4f, 0.2f);
            Plate(root.transform, "Sort", new Vector3(0f, 1.05f, 0f));
        }

        static void CutBooth(Transform parent, Vector3 at)
        {
            var root = new GameObject("Cut");
            root.transform.SetParent(parent, false);
            root.transform.position = at;
            Part(root.transform, "Booth", PrimitiveType.Cube, new Vector3(0f, 0.7f, 0f), new Vector3(0.8f, 1.2f, 0.7f), Vector3.zero, new Color(0.18f, 0.5f, 0.58f), 0.35f, 0.2f);
            Part(root.transform, "Window", PrimitiveType.Cube, new Vector3(0f, 0.85f, -0.32f), new Vector3(0.4f, 0.45f, 0.06f), Vector3.zero, new Color(0.7f, 0.9f, 0.95f), 0.8f, 0.1f);
            Plate(root.transform, "Cut", new Vector3(0f, 1.45f, 0f));
        }

        static void PolishBench(Transform parent, Vector3 at)
        {
            var root = new GameObject("Polish");
            root.transform.SetParent(parent, false);
            root.transform.position = at;
            Part(root.transform, "Bench", PrimitiveType.Cube, new Vector3(0f, 0.5f, 0f), new Vector3(0.9f, 0.7f, 0.6f), Vector3.zero, new Color(0.25f, 0.58f, 0.64f), 0.4f, 0.2f);
            Part(root.transform, "Wheel", PrimitiveType.Cylinder, new Vector3(0.2f, 0.95f, 0f), new Vector3(0.28f, 0.06f, 0.28f), new Vector3(0f, 0f, 90f), new Color(0.85f, 0.86f, 0.88f), 0.7f, 0.4f);
            Plate(root.transform, "Polish", new Vector3(0f, 1.3f, 0f));
        }

        static void Refinery(Transform parent, Vector3 at)
        {
            var root = new GameObject("Refinery");
            root.transform.SetParent(parent, false);
            root.transform.position = at;
            Part(root.transform, "Furnace", PrimitiveType.Cube, new Vector3(0f, 0.7f, 0f), new Vector3(0.9f, 1.3f, 0.8f), Vector3.zero, new Color(0.45f, 0.28f, 0.22f), 0.2f, 0.15f);
            Part(root.transform, "Glow", PrimitiveType.Cube, new Vector3(0f, 0.55f, -0.36f), new Vector3(0.35f, 0.28f, 0.08f), Vector3.zero, new Color(1f, 0.55f, 0.15f), 0.6f, 0f);
            Part(root.transform, "Stack", PrimitiveType.Cylinder, new Vector3(0.2f, 1.6f, 0.1f), new Vector3(0.16f, 0.4f, 0.16f), Vector3.zero, new Color(0.35f, 0.35f, 0.38f), 0.3f, 0.4f);
            Plate(root.transform, "Refine", new Vector3(0f, 2.1f, 0f));
        }

        static void Workshop(Transform parent, Vector3 at)
        {
            var root = new GameObject("Workshop");
            root.transform.SetParent(parent, false);
            root.transform.position = at;
            Part(root.transform, "Wall", PrimitiveType.Cube, new Vector3(0f, 0.8f, 0f), new Vector3(1.3f, 1.4f, 1f), Vector3.zero, new Color(0.93f, 0.86f, 0.7f), 0.15f, 0f);
            Part(root.transform, "Roof", PrimitiveType.Cube, new Vector3(0f, 1.6f, 0f), new Vector3(1.5f, 0.16f, 1.2f), new Vector3(0f, 0f, 8f), new Color(0.55f, 0.28f, 0.22f), 0.15f, 0f);
            Part(root.transform, "Bench", PrimitiveType.Cube, new Vector3(0.2f, 0.55f, -0.35f), new Vector3(0.7f, 0.12f, 0.3f), Vector3.zero, new Color(0.5f, 0.32f, 0.18f), 0.2f, 0f);
            Plate(root.transform, "Workshop", new Vector3(0f, 1.9f, -0.2f));
        }

        static void Boutique(Transform parent, Vector3 at)
        {
            var root = new GameObject("Boutique");
            root.transform.SetParent(parent, false);
            root.transform.position = at;
            Part(root.transform, "Shop", PrimitiveType.Cube, new Vector3(0f, 0.9f, 0f), new Vector3(1.8f, 1.6f, 1.4f), Vector3.zero, new Color(0.96f, 0.9f, 0.78f), 0.15f, 0f);
            Part(root.transform, "Awning", PrimitiveType.Cube, new Vector3(0f, 1.35f, -0.7f), new Vector3(1.9f, 0.08f, 0.55f), new Vector3(12f, 0f, 0f), new Color(0.2f, 0.55f, 0.62f), 0.2f, 0f);
            Part(root.transform, "Case", PrimitiveType.Cube, new Vector3(0f, 0.45f, -0.55f), new Vector3(1.2f, 0.5f, 0.3f), Vector3.zero, new Color(0.75f, 0.88f, 0.9f), 0.65f, 0.05f);
            Part(root.transform, "Gem", PrimitiveType.Sphere, new Vector3(0.15f, 0.75f, -0.55f), new Vector3(0.12f, 0.12f, 0.12f), Vector3.zero, new Color(0.55f, 0.9f, 0.95f), 0.8f, 0.1f);
            Plate(root.transform, "Boutique", new Vector3(0f, 1.9f, -0.3f));
        }

        static void Bin(Transform parent, Vector3 at, string label, Color fill)
        {
            var root = new GameObject(label + "Bin");
            root.transform.SetParent(parent, false);
            root.transform.position = at;
            Part(root.transform, "Crate", PrimitiveType.Cube, new Vector3(0f, 0.28f, 0f), new Vector3(1.05f, 0.45f, 0.75f), Vector3.zero, new Color(0.42f, 0.26f, 0.14f), 0.15f, 0f);
            Part(root.transform, "Fill", PrimitiveType.Cube, new Vector3(0f, 0.5f, 0f), new Vector3(0.85f, 0.18f, 0.55f), Vector3.zero, fill, 0.25f, 0.05f);
            Plate(root.transform, label, new Vector3(0f, 0.8f, 0f));
        }

        static void Conveyor(Transform parent, Vector3 at)
        {
            Part(parent, "Belt", PrimitiveType.Cube, at, new Vector3(0.9f, 0.08f, 0.28f), Vector3.zero, new Color(0.2f, 0.22f, 0.24f), 0.3f, 0.2f);
            for (int i = 0; i < 4; i++)
                Part(parent, "Roller", PrimitiveType.Cylinder, at + new Vector3(-0.3f + i * 0.2f, 0.02f, 0f), new Vector3(0.08f, 0.12f, 0.08f), new Vector3(0f, 0f, 90f), new Color(0.65f, 0.68f, 0.7f), 0.5f, 0.5f);
        }

        static void Rails(Transform parent, Vector3 from, Vector3 to)
        {
            Vector3 mid = (from + to) * 0.5f;
            Vector3 scale = new Vector3(Mathf.Abs(to.x - from.x), 0.04f, 0.05f);
            Part(parent, "RunL", PrimitiveType.Cube, mid + new Vector3(0f, 0.08f, -0.16f), scale, Vector3.zero, new Color(0.3f, 0.32f, 0.34f), 0.55f, 0.7f);
            Part(parent, "RunR", PrimitiveType.Cube, mid + new Vector3(0f, 0.08f, 0.16f), scale, Vector3.zero, new Color(0.3f, 0.32f, 0.34f), 0.55f, 0.7f);
        }

        static void Terrain(Transform parent)
        {
            const int nx = 40;
            const int nz = 48;
            const float sizeX = 26f;
            const float sizeZ = 30f;
            int vx = nx + 1;
            int vz = nz + 1;
            var vertices = new Vector3[vx * vz];
            var colors = new Color[vertices.Length];
            var uv = new Vector2[vertices.Length];
            for (int z = 0; z < vz; z++)
            {
                for (int x = 0; x < vx; x++)
                {
                    float fx = (x / (float)nx - 0.5f) * sizeX;
                    float fz = (z / (float)nz) * sizeZ - 8f;
                    float h = 0.06f * Mathf.Sin(fx * 0.55f) + 0.05f * Mathf.Cos(fz * 0.45f);
                    if (fz > 7.6f)
                        h += (fz - 7.6f) * 0.9f;
                    // The imported contoured trail owns this surface; keep the old grid below it.
                    if (fx > -10.4f && fx < -6.0f && fz > 3.35f && fz < 8.6f)
                        h = -.30f;
                    int index = z * vx + x;
                    vertices[index] = new Vector3(fx, h, fz);
                    uv[index] = new Vector2(x / (float)nx, z / (float)nz);
                    bool path = Mathf.Abs(fx + 1f) < 1.6f && fz < 7.2f && fz > -2f;
                    bool cliff = fz > 7.8f;
                    colors[index] = cliff
                        ? new Color(0.5f, 0.48f, 0.44f)
                        : path ? new Color(0.62f, 0.48f, 0.3f) : new Color(0.32f, 0.62f, 0.3f);
                }
            }
            var triangles = new int[nx * nz * 6];
            int t = 0;
            for (int z = 0; z < nz; z++)
            {
                for (int x = 0; x < nx; x++)
                {
                    int i = z * vx + x;
                    triangles[t++] = i;
                    triangles[t++] = i + vx;
                    triangles[t++] = i + 1;
                    triangles[t++] = i + 1;
                    triangles[t++] = i + vx;
                    triangles[t++] = i + vx + 1;
                }
            }
            var mesh = new Mesh();
            mesh.name = "YardTerrain";
            mesh.vertices = vertices;
            mesh.colors = colors;
            mesh.uv = uv;
            mesh.triangles = triangles;
            mesh.RecalculateNormals();
            var ground = new GameObject("Terrain");
            ground.transform.SetParent(parent, false);
            var filter = ground.AddComponent<MeshFilter>();
            filter.sharedMesh = mesh;
            var renderer = ground.AddComponent<MeshRenderer>();
            Shader shader = Shader.Find("DiamondMine/VertexLit");
            if (shader == null)
                shader = Shader.Find("Diffuse");
            renderer.sharedMaterial = new Material(shader);
            var water = Part(parent, "Stream", PrimitiveType.Cube, new Vector3(-10.5f, -0.15f, 1f), new Vector3(1.4f, 0.2f, 8f), Vector3.zero, new Color(0.25f, 0.55f, 0.72f), 0.7f, 0.05f);
            water.gameObject.isStatic = false;
        }

        static void Tree(Transform parent, Vector3 at, float scale)
        {
            var root = new GameObject("Tree");
            root.transform.SetParent(parent, false);
            root.transform.position = at;
            root.transform.localScale = Vector3.one * scale;
            Part(root.transform, "Trunk", PrimitiveType.Cylinder, new Vector3(0f, 0.45f, 0f), new Vector3(0.18f, 0.45f, 0.18f), Vector3.zero, new Color(0.38f, 0.24f, 0.12f), 0.1f, 0f);
            Part(root.transform, "LeafA", PrimitiveType.Sphere, new Vector3(0f, 1.15f, 0f), new Vector3(0.8f, 0.7f, 0.8f), Vector3.zero, new Color(0.18f, 0.48f, 0.22f), 0.05f, 0f);
            Part(root.transform, "LeafB", PrimitiveType.Sphere, new Vector3(0.2f, 1.45f, 0.1f), new Vector3(0.55f, 0.5f, 0.55f), Vector3.zero, new Color(0.28f, 0.58f, 0.26f), 0.05f, 0f);
        }

        static void PlaceCrew(Transform parent, string id, Vector3 at, float yaw)
        {
            Crew crew = BuildCrew(JourneyCatalog.FindCharacter(id), parent);
            crew.Root.position = at;
            crew.Root.rotation = Quaternion.Euler(0f, yaw, 0f);
        }

        static TextMesh Plate(Transform parent, string text, Vector3 local)
        {
            var board = new GameObject("Sign");
            board.transform.SetParent(parent, false);
            board.transform.localPosition = local;
            board.transform.localRotation = Quaternion.Euler(0f, 180f, 0f);
            TextMesh mesh = board.AddComponent<TextMesh>();
            mesh.text = text;
            mesh.fontSize = 48;
            mesh.characterSize = 0.045f;
            mesh.anchor = TextAnchor.MiddleCenter;
            mesh.alignment = TextAlignment.Center;
            mesh.color = new Color(0.12f, 0.08f, 0.05f);
            Font font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (font != null)
                mesh.font = font;
            return mesh;
        }

        static Transform Joint(Transform parent, string name, PrimitiveType type, Vector3 local, Vector3 scale, Vector3 euler, Color color, float smooth, float metal)
        {
            // Mesh scale must not shrink every descendant of an animated joint.
            var pivot = new GameObject(name);
            pivot.transform.SetParent(parent, false);
            pivot.transform.localPosition = local;
            pivot.transform.localRotation = Quaternion.Euler(euler);
            Part(pivot.transform, name + "Mesh", type, Vector3.zero, scale, Vector3.zero, color, smooth, metal);
            return pivot.transform;
        }

        static Transform Part(Transform parent, string name, PrimitiveType type, Vector3 local, Vector3 scale, Vector3 euler, Color color, float smooth, float metal)
        {
            GameObject block = GameObject.CreatePrimitive(type);
            block.name = name;
            Collider collider = block.GetComponent<Collider>();
            if (collider != null)
            {
                if (Application.isPlaying)
                    Object.Destroy(collider);
                else
                    Object.DestroyImmediate(collider);
            }
            block.transform.SetParent(parent, false);
            block.transform.localPosition = local;
            block.transform.localScale = scale;
            block.transform.localRotation = Quaternion.Euler(euler);
            Renderer renderer = block.GetComponent<Renderer>();
            Shader shader = Shader.Find("Standard");
            if (shader == null)
                shader = Shader.Find("Diffuse");
            var material = new Material(shader);
            material.color = color;
            if (shader != null && shader.name == "Standard")
            {
                material.SetFloat("_Glossiness", smooth);
                material.SetFloat("_Metallic", metal);
            }
            renderer.sharedMaterial = material;
            return block.transform;
        }

        static float Tall(string id)
        {
            if (id == "oren" || id == "daro")
                return 1.12f;
            if (id == "pavi" || id == "etta" || id == "rumi")
                return 0.96f;
            return 1f;
        }

        static float Wide(string id)
        {
            if (id == "zela" || id == "beni" || id == "mira")
                return 1.12f;
            if (id == "oren" || id == "nilo")
                return 0.92f;
            return 1f;
        }

        static Color Hex(int hex)
        {
            return new Color(((hex >> 16) & 255) / 255f, ((hex >> 8) & 255) / 255f, (hex & 255) / 255f, 1f);
        }
    }
}

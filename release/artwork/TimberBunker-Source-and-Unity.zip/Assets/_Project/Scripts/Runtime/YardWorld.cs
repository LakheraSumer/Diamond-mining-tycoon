using DiamondMine.Simulation;
using UnityEngine;

namespace DiamondMine.Runtime
{
    /// <summary>
    /// Local yard for the starter bunkers. Distant plots stay as data until a page is opened.
    /// </summary>
    public sealed class YardWorld : MonoBehaviour
    {
        Camera view;
        Light yardSun;
        TimberBunkerArea timberArea;
        bool shown;
        bool cartWasRiding;
        Vector3[] haulRoute;
        Vector3 previousCartPosition;
        Transform[] cartWheels;
        bool areaFraming;
        public TimberBunkerArea TimberArea { get { return timberArea; } }
        public Transform TransportCart { get { return cart; } }
        public Transform Player { get { return player; } }

        // Also used by the art review camera. This changes presentation only.
        public void FrameTimberArea(bool enabled) { areaFraming = enabled; cameraReady = false; }
        Transform player;
        Transform arm;
        Transform toolSocket;
        Transform helmet;
        Transform cloth;
        Transform accent;
        Transform head;
        Renderer[] accessoryRenderers;
        string shownCharacter = "";
        string pose = "idle";
        float poseTime;
        Vector3 cameraPosition;
        bool cameraReady;
        TextMesh[] bunkerLabels;
        TextMesh[] billboards;
        Transform cart;
        bool hasMove;
        Vector3 moveTarget;
        public float Facing;

        public bool HasMove { get { return hasMove; } }
        public Vector3 MoveTarget { get { return moveTarget; } }

        public void SetMoveTarget(float x, float z)
        {
            hasMove = true;
            moveTarget = new Vector3(x, 0f, z);
        }

        public void ClearMove()
        {
            hasMove = false;
        }

        public Camera View { get { return view; } }

        void Awake()
        {
            var cameraObject = new GameObject("YardCamera");
            cameraObject.transform.SetParent(transform, false);
            view = cameraObject.AddComponent<Camera>();
            view.depth = 1f;
            view.clearFlags = CameraClearFlags.SolidColor;
            view.backgroundColor = new Color(0.55f, 0.78f, 0.92f);
            view.fieldOfView = 42f;
            view.nearClipPlane = 0.05f;
            view.farClipPlane = 80f;
            view.enabled = false;

            var sunObject = new GameObject("YardLight");
            sunObject.transform.SetParent(transform, false);
            sunObject.transform.rotation = Quaternion.Euler(52f, -28f, 0f);
            Light sun = sunObject.AddComponent<Light>();
            yardSun = sun;
            sun.type = LightType.Directional;
            sun.color = new Color(1f, 0.94f, 0.84f);
            sun.intensity = 1.12f;
            sun.shadows = LightShadows.Soft;
            sun.shadowStrength = .80f;
            sun.shadowBias = .035f;
            sun.shadowNormalBias = .16f;
            sun.enabled = false;
            timberArea = YardArt.BuildSite(transform);
            bunkerLabels = YardArt.BunkerLabels;
            cart = TimberBunkerArea.CreateCart(transform);
            if (cart != null)
            {
                var wheels = new System.Collections.Generic.List<Transform>();
                foreach (Transform part in cart.GetComponentsInChildren<Transform>())
                    if (part.name.StartsWith("Wheel_",System.StringComparison.Ordinal)) wheels.Add(part);
                cartWheels = wheels.ToArray();
                cart.gameObject.SetActive(false);
            }
        }

        public void SetShown(bool shown)
        {
            this.shown = shown;
            if (view != null)
                view.enabled = shown;
            if (yardSun != null) yardSun.enabled = shown;
            if (timberArea != null) timberArea.Present(cartWasRiding, shown);
            if (shown)
            {
                RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
                RenderSettings.ambientSkyColor = new Color(.53f,.62f,.73f);
                RenderSettings.ambientEquatorColor = new Color(.40f,.42f,.40f);
                RenderSettings.ambientGroundColor = new Color(.23f,.20f,.16f);
                QualitySettings.pixelLightCount = Mathf.Max(2, QualitySettings.pixelLightCount);
            }
        }

        public void Present(GameSession session)
        {
            if (session == null || !session.Ready || session.State == null || session.State.Adventure == null)
                return;
            AdventureState adventure = session.State.Adventure;
            if (player == null || shownCharacter != (adventure.SelectedCharacter ?? ""))
                ApplyLook(adventure);
            if (player == null)
                return;
            player.position = new Vector3((float)adventure.PlayerX, 0f, (float)adventure.PlayerZ);
            player.rotation = Quaternion.Euler(0f, Facing, 0f);
            PaintBunkers(adventure);
            PlaceCart(adventure);
            FaceSigns();
            PoseInput input = BuildPose(adventure);
            pose = PuppetPose.Resolve(input);
            float dt = session.State.Settings.ReducedMotion ? 0f : Time.unscaledDeltaTime;
            poseTime += dt;
            Animate(dt <= 0f);
            FollowCamera(player.position, session.State.Settings.ReducedMotion);
        }

        static PoseInput BuildPose(AdventureState adventure)
        {
            return new PoseInput
            {
                Moving = adventure.PoseHint == "move",
                Sprint = adventure.PoseHint == "run",
                Carrying = adventure.HandsAmount > 0d,
                Mining = adventure.PoseHint == "mine",
                Collecting = adventure.PoseHint == "collect",
                UsingMachine = adventure.PoseHint == "machine",
                Crafting = adventure.PoseHint == "craft" || HasOpenJob(adventure),
                CelebrateSeconds = adventure.PoseCelebrate,
                WaveSeconds = adventure.PoseWave
            };
        }

        static bool HasOpenJob(AdventureState adventure)
        {
            for (int i = 0; i < adventure.Jobs.Count; i++)
            {
                if (!adventure.Jobs[i].OutputGranted)
                    return true;
            }
            return false;
        }

        void ApplyLook(AdventureState adventure)
        {
            shownCharacter = adventure.SelectedCharacter ?? "";
            CharacterDef person = JourneyCatalog.FindCharacter(shownCharacter);
            if (person == null)
                person = JourneyCatalog.AllCharacters[0];
            Vector3 position = player != null ? player.position : Vector3.zero;
            float yaw = player != null ? player.eulerAngles.y : Facing;
            if (player != null)
                Destroy(player.gameObject);
            YardArt.Crew crew = YardArt.BuildCrew(person, transform);
            player = crew.Root;
            cloth = crew.Cloth;
            head = crew.Head;
            helmet = crew.Helmet;
            arm = crew.Arm;
            toolSocket = crew.ToolSocket;
            player.position = position;
            player.rotation = Quaternion.Euler(0f, yaw, 0f);
        }

        void Animate(bool frozen)
        {
            float swing = frozen ? 0f : Mathf.Sin(poseTime * 6f) * 25f;
            if (arm == null)
                return;
            if (pose == "mine" || pose == "machine" || pose == "craft")
                arm.localRotation = Quaternion.Euler(frozen ? -40f : -40f + swing, 0f, 0f);
            else if (pose == "walk" || pose == "run" || pose == "carry")
                arm.localRotation = Quaternion.Euler(frozen ? 0f : swing * 0.4f, 0f, 0f);
            else if (pose == "wave" || pose == "celebrate")
                arm.localRotation = Quaternion.Euler(-120f, 0f, frozen ? 20f : 20f + swing);
            else
                arm.localRotation = Quaternion.identity;
        }

        void FollowCamera(Vector3 target, bool reducedMotion)
        {
            YardPoint entrance = YardLayout.Entrance(0);
            Vector3 focus = new Vector3((float)entrance.X-.15f, 1.1f, (float)entrance.Z-.28f);
            bool nearTimber = areaFraming || Vector2.Distance(new Vector2(target.x,target.z),
                new Vector2((float)entrance.X,(float)entrance.Z)) < 2.8f;
            if (nearTimber)
            {
                view.orthographic = true;
                view.orthographicSize = Mathf.Max(2.65f,2.65f/Mathf.Max(.3f,view.aspect));
                Vector3 position = focus + new Vector3(4.8f,3.7f,-7.2f);
                cameraPosition = !cameraReady || reducedMotion ? position :
                    Vector3.Lerp(cameraPosition,position,1f-Mathf.Exp(-6f*Time.unscaledDeltaTime));
                cameraReady = true;
                view.transform.position = cameraPosition;
                view.transform.LookAt(focus);
                return;
            }
            view.orthographic = false;
            Vector3 desired = target + new Vector3(-6.5f, 9.5f, -7.2f);
            desired.x = Mathf.Clamp(desired.x, -6f, 6f);
            desired.z = Mathf.Clamp(desired.z, -8f, 12f);
            if (!cameraReady || reducedMotion)
            {
                cameraPosition = desired;
                cameraReady = true;
            }
            else
            {
                cameraPosition = Vector3.Lerp(cameraPosition, desired, 1f - Mathf.Exp(-6f * Time.unscaledDeltaTime));
            }
            view.transform.position = cameraPosition;
            view.transform.LookAt(target + new Vector3(0f, 0.8f, 0f));
        }

        void DressYard(Shader shader)
        {
            Sign("Factory", new Vector3(0f, 1.7f, 0.8f));
            Sign("Boutique", new Vector3(4.2f, 1.55f, -1.2f));
            Sign("Home", new Vector3(0f, 0.7f, -0.2f));
            string[] stages = { "Crush", "Wash", "Sort", "Cut", "Polish" };
            for (int i = 0; i < stages.Length; i++)
            {
                float x = -3.4f + i * 1.7f;
                BuildBlock(shader, stages[i], new Vector3(x, 0.45f, 2.7f), new Vector3(1.15f, 0.7f, 0.8f), new Color(0.35f, 0.55f, 0.62f));
                Sign(stages[i], new Vector3(x, 1.15f, 2.7f));
            }
            BuildBlock(shader, "Refinery", new Vector3(5.4f, 0.55f, 2.7f), new Vector3(1.2f, 0.9f, 0.9f), new Color(0.72f, 0.38f, 0.22f));
            Sign("Refinery", new Vector3(5.4f, 1.3f, 2.7f));
            BuildBlock(shader, "Workshop", new Vector3(6.6f, 0.5f, 0.4f), new Vector3(1.3f, 0.8f, 1f), new Color(0.62f, 0.42f, 0.28f));
            Sign("Workshop", new Vector3(6.6f, 1.2f, 0.4f));
            string[] bins = { "Stone", "Iron", "Copper", "Silver", "Gold" };
            Color[] binColors =
            {
                new Color(0.62f, 0.6f, 0.55f),
                new Color(0.55f, 0.34f, 0.28f),
                new Color(0.72f, 0.45f, 0.24f),
                new Color(0.72f, 0.74f, 0.78f),
                new Color(0.86f, 0.68f, 0.22f)
            };
            for (int i = 0; i < bins.Length; i++)
            {
                float x = -6.2f + i * 1.35f;
                BuildBlock(shader, bins[i] + "Bin", new Vector3(x, 0.28f, -2.6f), new Vector3(1f, 0.45f, 0.7f), binColors[i]);
                Sign(bins[i], new Vector3(x, 0.75f, -2.6f));
            }
            Sign("Pavi", new Vector3(1.7f, 1.15f, 0.8f));
            Sign("Sola", new Vector3(4.2f, 1.15f, -2.3f));
            BuildBlock(shader, "GuidePavi", new Vector3(1.7f, 0.45f, 0.8f), new Vector3(0.4f, 0.9f, 0.35f), new Color(0.1f, 0.55f, 0.58f));
            BuildBlock(shader, "GuideSola", new Vector3(4.2f, 0.45f, -2.3f), new Vector3(0.4f, 0.9f, 0.35f), new Color(0.45f, 0.55f, 0.38f));
            YardPoint diamond = YardLayout.Entrance(2);
            for (int i = 1; i <= 6; i++)
            {
                float t = i / 7f;
                var point = new Vector3(Mathf.Lerp(0f, (float)diamond.X, t), 0.08f, Mathf.Lerp(-0.2f, (float)diamond.Z, t));
                BuildBlock(shader, "MillPath", point, new Vector3(0.22f, 0.08f, 0.22f), new Color(0.93f, 0.86f, 0.45f));
            }
            for (int i = 1; i <= 4; i++)
            {
                float t = i / 5f;
                var point = new Vector3(Mathf.Lerp(0f, 4.2f, t), 0.12f, Mathf.Lerp(-0.2f, -1.2f, t));
                GameObject post = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                post.name = "ShopPath";
                Collider collider = post.GetComponent<Collider>();
                if (collider != null)
                    Destroy(collider);
                post.transform.position = point;
                post.transform.localScale = new Vector3(0.12f, 0.18f, 0.12f);
                Renderer renderer = post.GetComponent<Renderer>();
                renderer.sharedMaterial = new Material(shader);
                renderer.sharedMaterial.color = new Color(0.95f, 0.55f, 0.35f);
            }
            cart = BuildBlock(shader, "HaulCart", new Vector3(0f, 0.25f, 0.8f), new Vector3(0.55f, 0.28f, 0.4f), new Color(0.55f, 0.32f, 0.16f)).transform;
            cart.gameObject.SetActive(false);
        }

        static string BunkerWord(int plot)
        {
            if (plot == 0)
                return "Stone";
            if (plot == 1)
                return "Copper";
            if (plot == 2)
                return "Diamond";
            if (plot == 3)
                return "Silver";
            if (plot == 4)
                return "Mixed";
            return "Buy";
        }

        TextMesh Sign(string text, Vector3 position)
        {
            var board = new GameObject("Sign");
            board.transform.position = position;
            TextMesh mesh = board.AddComponent<TextMesh>();
            mesh.text = text;
            mesh.fontSize = 48;
            mesh.characterSize = 0.06f;
            mesh.anchor = TextAnchor.MiddleCenter;
            mesh.alignment = TextAlignment.Center;
            mesh.color = new Color(0.12f, 0.08f, 0.05f);
            Font font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (font != null)
                mesh.font = font;
            if (billboards == null)
                billboards = new TextMesh[0];
            var next = new TextMesh[billboards.Length + 1];
            for (int i = 0; i < billboards.Length; i++)
                next[i] = billboards[i];
            next[billboards.Length] = mesh;
            billboards = next;
            return mesh;
        }

        void PaintBunkers(AdventureState adventure)
        {
            if (bunkerLabels == null)
                return;
            for (int plot = 0; plot < bunkerLabels.Length; plot++)
            {
                bool owned = adventure.Owned.Get(plot);
                if (bunkerLabels[plot] != null)
                {
                    string word = plot < WorldGenerator.StarterCount ? BunkerWord(plot) : (owned ? "Yours" : "Buy");
                    bunkerLabels[plot].text = (plot + 1) + "\n" + word;
                }
            }
        }

        void PlaceCart(AdventureState adventure)
        {
            if (cart == null)
                return;
            bool riding = adventure.CartLoad > 0d && !adventure.CartGranted;
            if (timberArea != null) timberArea.Present(riding && adventure.FocusPlotId == 0, shown);
            cart.gameObject.SetActive(riding);
            if (!riding)
            {
                cartWasRiding = false;
                return;
            }
            if (!cartWasRiding)
            {
                BuildHaulRoute(adventure);
                previousCartPosition = RoutePoint(0f);
            }
            cartWasRiding = true;
            float span = (float)JourneyCatalog.CartTripSeconds;
            float along = span <= 0f ? 1f : 1f - Mathf.Clamp01((float)adventure.CartSeconds / span);
            Vector3 next = RoutePoint(along);
            Vector3 ahead = RoutePoint(Mathf.Min(1f,along+.005f))-next;
            if (ahead.sqrMagnitude>.00001f) cart.rotation=Quaternion.LookRotation(ahead.normalized,Vector3.up);
            float distance=Vector3.Distance(previousCartPosition,next);
            if(cartWheels!=null) foreach(Transform wheel in cartWheels)
                wheel.Rotate(cart.right,distance/.125f*Mathf.Rad2Deg,Space.World);
            cart.position = next;
            previousCartPosition = next;
        }

        void BuildHaulRoute(AdventureState adventure)
        {
            var points = new System.Collections.Generic.List<Vector3>();
            if (adventure.FocusPlotId == 0)
            {
                YardPoint door=YardLayout.Entrance(0);
                float x=(float)door.X,z=(float)door.Z;
                points.Add(new Vector3(x,0,z-.98f));
                points.Add(new Vector3(x,0,z-1.09f));
                for(int i=1;i<=12;i++)
                {
                    float a=i/12f*Mathf.PI*.5f;
                    points.Add(new Vector3(x+.85f-.85f*Mathf.Cos(a),0,z-1.09f-.85f*Mathf.Sin(a)));
                }
                points.Add(new Vector3(0,0,z-1.94f));
            }
            else points.Add(new Vector3((float)adventure.PlayerX,0,(float)adventure.PlayerZ));
            points.Add(new Vector3(0,0,.8f));
            haulRoute=points.ToArray();
        }

        Vector3 RoutePoint(float t)
        {
            if(haulRoute==null || haulRoute.Length<2) return Vector3.zero;
            float total=0;
            for(int i=1;i<haulRoute.Length;i++) total+=Vector3.Distance(haulRoute[i-1],haulRoute[i]);
            float remaining=Mathf.Clamp01(t)*total;
            for(int i=1;i<haulRoute.Length;i++)
            {
                float length=Vector3.Distance(haulRoute[i-1],haulRoute[i]);
                if(remaining<=length) return Vector3.Lerp(haulRoute[i-1],haulRoute[i],length<.0001f?1:remaining/length);
                remaining-=length;
            }
            return haulRoute[haulRoute.Length-1];
        }

        void FaceSigns()
        {
            if (billboards == null || view == null)
                return;
            for (int i = 0; i < billboards.Length; i++)
            {
                if (billboards[i] == null)
                    continue;
                Vector3 toward = view.transform.position - billboards[i].transform.position;
                if (toward.sqrMagnitude > 0.01f)
                    billboards[i].transform.rotation = Quaternion.LookRotation(toward);
            }
        }

        void BuildPlayer(Shader shader)
        {
            player = BuildBlock(shader, "Miner", Vector3.zero, new Vector3(0.55f, 0.9f, 0.4f), new Color(0.3f, 0.45f, 0.55f)).transform;
            cloth = player;
            head = BuildBlock(shader, "Head", new Vector3(0f, 0.72f, 0f), new Vector3(0.38f, 0.38f, 0.38f), new Color(0.8f, 0.64f, 0.45f)).transform;
            head.SetParent(player, false);
            helmet = BuildBlock(shader, "Helmet", new Vector3(0f, 0.22f, 0f), new Vector3(0.46f, 0.22f, 0.46f), Color.cyan).transform;
            helmet.SetParent(head, false);
            arm = BuildBlock(shader, "Arm", new Vector3(0.38f, 0.15f, 0.1f), new Vector3(0.16f, 0.45f, 0.16f), new Color(0.8f, 0.64f, 0.45f)).transform;
            arm.SetParent(player, false);
            toolSocket = new GameObject("ToolSocket").transform;
            toolSocket.SetParent(arm, false);
            toolSocket.localPosition = new Vector3(0f, -0.28f, 0.1f);
            accent = BuildBlock(shader, "Tool", Vector3.zero, new Vector3(0.12f, 0.28f, 0.12f), Color.gray).transform;
            accent.SetParent(toolSocket, false);
            string[] names = { "scarf", "pouch", "pads", "tubes", "gloves", "goggles", "tray", "glasses", "cloth", "loop", "badge", "cart", "blueprint" };
            accessoryRenderers = new Renderer[names.Length];
            for (int i = 0; i < names.Length; i++)
            {
                GameObject piece = BuildBlock(shader, names[i], new Vector3(0f, 0.2f, 0.28f), new Vector3(0.22f, 0.12f, 0.08f), Color.white);
                piece.transform.SetParent(player, false);
                accessoryRenderers[i] = piece.GetComponent<Renderer>();
                accessoryRenderers[i].enabled = false;
            }
        }

        static void Paint(Transform target, int hex)
        {
            if (target == null)
                return;
            Renderer renderer = target.GetComponent<Renderer>();
            if (renderer != null)
                renderer.material.color = Hex(hex);
        }

        static Color Hex(int hex)
        {
            return new Color(((hex >> 16) & 255) / 255f, ((hex >> 8) & 255) / 255f, (hex & 255) / 255f, 1f);
        }

        static GameObject BuildBlock(Shader shader, string name, Vector3 position, Vector3 scale, Color color)
        {
            GameObject block = GameObject.CreatePrimitive(PrimitiveType.Cube);
            block.name = name;
            Collider collider = block.GetComponent<Collider>();
            if (collider != null)
                Destroy(collider);
            block.transform.position = position;
            block.transform.localScale = scale;
            Renderer renderer = block.GetComponent<Renderer>();
            renderer.sharedMaterial = new Material(shader);
            renderer.sharedMaterial.color = color;
            return block;
        }
    }
}
